import os
from langchain.text_splitter import CharacterTextSplitter,RecursiveCharacterTextSplitter

from langchain_community.document_loaders import TextLoader
from langchain_chroma import Chroma
from langchain_openai import OpenAIEmbeddings

from langchain_openai.embeddings.azure import AzureOpenAIEmbeddings
from langchain_core.documents import Document

from langchain_openai.chat_models import AzureChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage

from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains.history_aware_retriever import create_history_aware_retriever
from langchain.chains.retrieval import create_retrieval_chain
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder

file_dir = "C:/AIAgent/data/sampleStory.txt"
db_dir  = "C:/AIAgent/data/Chroma_ovelap"


def createEmbeddings(file_dir,db_dir,OpenAIEmbedding):

    if os.path.exists(db_dir):
        print("db already exist")
        return

    loader = TextLoader(file_path=file_dir)
    doc = loader.load()

    text_splitter = CharacterTextSplitter(chunk_size = 1000, chunk_overlap = 0)
    docs = text_splitter.split_documents(doc)

    vector_store = Chroma.from_documents(
        documents=docs,
        embedding= OpenAIEmbedding,
        persist_directory=db_dir
    )

    return

def askQuery(query, db_dir,OpenAIEmbedding):
    db = Chroma(
        persist_directory=db_dir,
        embedding_function=OpenAIEmbedding
    )

    retreiver = db.as_retriever(
        search_type = "similarity",
        search_kwargs = {"k" : 3},
    )

    result = retreiver.invoke(query)

    return result

def chatModel(result:Document,OpenAIchat: AzureChatOpenAI,query:str):

    input = (
        "Here are some documents that can help answer the question :"
        + query
        + "\n\n Relevant Documents:\n"
        + "\n\n".join([doc.page_content for doc in result])
        + "\n\n Please provide an answer based on the provided documents."
    )

    # print(input)
    
    message = [
        SystemMessage(content = "You are an AI assistant that helps people find information."),
        HumanMessage(content=input)
    ]

    result = OpenAIchat.invoke(message)

    return result


def startChat(db_dir: str,OpenAIEmbedding:AzureOpenAIEmbeddings,OpenAIchat:AzureChatOpenAI):

    db = Chroma(
        persist_directory=db_dir,
        embedding_function=OpenAIEmbedding
    )

    retreiver = db.as_retriever(
        search_type = "similarity",
        search_kwargs = {"k" : 3},
    )

    contextulaize_q_system_prompt = (
        "You are a helpful assistant that rewrites follow-up questions to make them fully self-contained. "
        "Given the chat history and a user’s latest question, reformulate it into a standalone version "
        "that can be understood without any prior context. "
        "Only rewrite if necessary. Do NOT answer the question — just return the rewritten or original question."
    )

    contextulaize_q_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", contextulaize_q_system_prompt),
            MessagesPlaceholder("chat_history"),
            ("human","{input}"),
        ]
    )

    history_aware_retreiver = create_history_aware_retriever(
        llm=OpenAIchat,retriever=retreiver,prompt=contextulaize_q_prompt
    )

    qa_system_prompt = (
        "You are a helpful and concise assistant. Use the following retrieved context from documents "
        "to answer the user's question. Respond only based on the given context.\n\n"
        "- If the answer is not explicitly stated, say: 'I don’t know based on the provided information.'\n"
        "- Be concise and to the point.\n"
        "- Do not include unrelated information.\n\n"
        "Context:\n{context}"
    )
    qa_prompt = ChatPromptTemplate.from_messages(
        [
            ('system',qa_system_prompt),
            MessagesPlaceholder("chat_history"),
            ("human","{input}"),
        ]
    )
    question_answer_chain = create_stuff_documents_chain(llm = OpenAIchat,prompt=qa_prompt)
    rag_chain = create_retrieval_chain(history_aware_retreiver,question_answer_chain)

    print("Start chatting with the AI, Type exit to end:")
    chat_history = []
    while True:
        query = input("you :")
        if query.lower() == "exit":
            break

        result = rag_chain.invoke({"input" : query,"chat_history": chat_history})

        print(f"AI : {result['answer']}")

        chat_history.append(HumanMessage(content=query))
        chat_history.append(SystemMessage(content = result["answer"]))  

    return 

if __name__ == "__main__":
    # For Serverless API or Managed Compute endpoints
    endpoint = "https://aishtestembeddings.openai.azure.com/"
    API_KEY = "5GQDXS1hx0uEzSlogogGzcxWqzzKzSbZaytOQxJZxCAeNXdhDGNiJQQJ99BEACYeBjFXJ3w3AAABACOGjBqD"
    model_name = "text-embedding-3-small"

    OpenAIEmbedding = AzureOpenAIEmbeddings(
        model = model_name,
        azure_endpoint=endpoint,
        api_key = API_KEY,
    )

    createEmbeddings(file_dir=file_dir,db_dir=db_dir,OpenAIEmbedding=OpenAIEmbedding)

    # query = input("you:")

    # result = askQuery(query=query,db_dir=db_dir,OpenAIEmbedding=OpenAIEmbedding)

    # print("------------Retreived docs-------------------")
    # print(result)
    # print("---------------------------------------------")

    OpenAIchat = AzureChatOpenAI(
        azure_endpoint="https://aishtestopenaichat.openai.azure.com/",
        api_key= "7Zd1cbkuaQKxyuYVGGKq8lxkN08kG6Q7SiHq3wjyagBBdBwhromeJQQJ99BEACYeBjFXJ3w3AAABACOGdws1",
        model = "gpt-4o-mini",
        api_version= "2024-12-01-preview"
    )

    # print(chatModel(result = result, OpenAIchat=OpenAIchat, query = query).content)

    startChat(
        db_dir=db_dir,
        OpenAIEmbedding=OpenAIEmbedding,
        OpenAIchat=OpenAIchat
    )
    