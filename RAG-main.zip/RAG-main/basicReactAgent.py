from langchain import hub
from langchain.agents import AgentExecutor, create_structured_chat_agent
from langchain.memory import ConversationBufferMemory
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.tools import Tool, StructuredTool

from langchain_openai.chat_models import AzureChatOpenAI


def get_current_time(*args, **kwargs) -> str:
    """ Returns the current time in H:MM AM/PM format."""

    import datetime

    now = datetime.datetime.now()
    return now.strftime("%I:%M %p")

def search_wikipedia(query):

    """search Wikipedia and retuns the summary of the first result."""

    from wikipedia import summary

    try:
        return summary(query, sentence = 2)
    except:
        return "I couldn't find any information on that."
    

tools = [
    StructuredTool.from_function(
        name="Time",
        func=get_current_time,
        description="Useful for when you need to know the current time."
    ),
    # Tool(
    #     name = "Time",
    #     func=get_cirrent_time,
    #     description="Useful for when you need to know the current time",
    # ),
    Tool(
        name="wikipedia",
        func=search_wikipedia,
        description="Useful for when you need to know information about a topic."
    )
]

prompt = hub.pull("hwchase17/structured-chat-agent")   #React prompt template 
# print(prompt)

llm = AzureChatOpenAI(
    azure_endpoint="https://aishtestopenaichat.openai.azure.com/",
    api_key= "7Zd1cbkuaQKxyuYVGGKq8lxkN08kG6Q7SiHq3wjyagBBdBwhromeJQQJ99BEACYeBjFXJ3w3AAABACOGdws1",
    model = "gpt-4o-mini",
    api_version= "2024-12-01-preview"
)


memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

agent = create_structured_chat_agent(llm = llm,tools=tools,prompt=prompt)

agent_executor = AgentExecutor.from_agent_and_tools(
    agent=agent,
    tools = tools,
    verbose = True,
    memory = memory,
    handle_parsing_errors = True,
)
    
initial_messsage = "you are an AI assistant that can provide helpful answers using available tools. \n If you are unable to answer just you dont know."
memory.chat_memory.add_message(SystemMessage(content=initial_messsage))

while True:
    print("you:")
    query = input()

    if query == "exit":
        break

    # memory.chat_memory.add_message(HumanMessage(content=query))

    response = agent_executor.invoke(input={"input":query})
    print("AI:", response["output"])

    # memory.chat_memory.add_message(AIMessage(content=response["output"]))

    # print(memory.chat_memory)