from langchain_openai import ChatOpenAI
import os, httpx, json

client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    api_key="sk-Z6ZvcQAwUGMOReylW5me4Q",
    model="azure_ai/genailab-maas-Llama-3.3-70B-Instruct",
    http_client=client
)

def anonymize_text(text: str):
    """
    Uses a local model to detect and redact PII from text.
    """
    prompt = f"""You are a data privacy assistant. Redact all personally identifiable information (PII) from the following text. Replace names, phone numbers, emails, and addresses with [REDACTED].

Text: {text}

Anonymized:"""

    response = llm.invoke(prompt)  # Replace with your actual method
    anonymized_text = response.content

    return {
        "has_pii": anonymized_text != text,
        "pii_entities": [],  # Optional: parse if your model returns structured data
        "anonymized_text": anonymized_text
    }

# Example usage
if __name__ == "__main__":
    sample = "My name is John Doe. Email me at john.doe@example.com or call +1-202-555-0178."
    print(anonymize_text(sample))