from langchain_openai import ChatOpenAI
import os, httpx, json

client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    api_key="sk-Z6ZvcQAwUGMOReylW5me4Q",
    model="azure/genailab-maas-gpt-4o-mini",
    http_client=client
)

def check_toxicity(llm, text):
    prompt = f"Is this text toxic: {text}, Please respond with a json output only with keys as toxicity (values true or false), and toxicity_score"
    response = llm.invoke(prompt)
    # print(response)

    # Step 1: Extract the content string
    content = response.content

    # Step 2: Clean the Markdown-style code block
    cleaned = content.strip("`").replace("json\n", "").strip()

    # Step 3: Parse the JSON string into a Python dictionary
    data = json.loads(cleaned)
    print(data)    
    return data

text = 'I hate you and everyone like you.'
data = check_toxicity(llm, text)
print("Toxicity:", data["toxicity"])
print("Score:", data["toxicity_score"])