import streamlit as st
import json, httpx
import plotly.graph_objects as go
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

# ---------------------- CONFIG ----------------------
st.set_page_config(page_title="Conversational Quality Evaluator", page_icon="🤖", layout="centered")
st.title("🤖 Conversational Quality Evaluator (LLM-as-a-Judge)")

st.markdown("""
Use any **OpenAI-compatible LLM endpoint** to evaluate the quality of chatbot responses.

Enter your **API Key** and **Base URL** below 👇  
*(Works with OpenAI, LM Studio, Ollama, vLLM, etc.)*
""")

# --- User inputs for LLM config ---
api_key = st.text_input("🔑 API Key", type="password", placeholder="sk-...")
base_url = st.text_input("🌐 Base URL", placeholder="https://api.openai.com/v1")
model_name = st.text_input("🧠 Model name", value="gpt-4")

# --- Conversation inputs ---
st.markdown("---")
st.subheader("💬 Conversation Inputs")
user_query = st.text_area("🧑 User Query", placeholder="e.g. Explain quantum computing in simple terms.")
assistant_response = st.text_area("🤖 Assistant Response", placeholder="e.g. Quantum computing uses qubits to perform calculations in parallel...")
reference = st.text_area("📘 Reference Answer (optional)", placeholder="If you have a gold-standard or expected answer.")

# --- Prompt for evaluation ---
EVAL_PROMPT = """
You are an expert evaluator of conversational AI systems.
Evaluate the ASSISTANT RESPONSE for the given USER QUERY.

Rate each of the following dimensions from 1 to 5 (higher = better):
- Relevance: how well it answers the question.
- Coherence: how fluent and logically consistent it is.
- Factuality: correctness of information.
- Helpfulness: how useful it is.
- Politeness: whether it maintains a respectful tone.

Return a **valid JSON object only**, in this exact format:
{
  "relevance": <float>,
  "coherence": <float>,
  "factuality": <float>,
  "helpfulness": <float>,
  "politeness": <float>
}
"""

# ---------------------- Evaluation Logic ----------------------
def evaluate_response(user_query, assistant_response, reference=None):
    client = httpx.Client(verify=False)

    llm = ChatOpenAI(
        base_url="https://genailab.tcs.in",
        api_key="sk-Z6ZvcQAwUGMOReylW5me4Q",
        model="azure/genailab-maas-gpt-4o-mini",
        temperature=0.0,
        http_client=client
    )
    # llm = ChatOpenAI(
    #     model_name=model_name,
    #     openai_api_key=api_key,
    #     openai_api_base=base_url,
    #     temperature=0.0,
    #     max_tokens=300
    # )

    messages = [
        SystemMessage(content=EVAL_PROMPT),
        HumanMessage(
            content=f"USER QUERY:\n{user_query}\n\nASSISTANT RESPONSE:\n{assistant_response}\n\nREFERENCE (if any):\n{reference or 'N/A'}"
        )
    ]

    response = llm(messages)
    text_output = response.content

    try:
        start = text_output.find("{")
        end = text_output.rfind("}") + 1
        metrics = json.loads(text_output[start:end])
    except Exception as e:
        st.error(f"⚠️ Could not parse JSON output: {e}")
        st.write("Raw response:", text_output)
        return None

    return metrics

# ---------------------- Streamlit UI ----------------------
if st.button("Evaluate Quality 🚀"):
    if not (api_key and base_url and model_name):
        st.warning("Please provide API key, base URL, and model name.")
    elif not (user_query and assistant_response):
        st.warning("Please provide both user query and assistant response.")
    else:
        with st.spinner("Evaluating..."):
            metrics = evaluate_response(user_query, assistant_response, reference)

        if metrics:
            st.success("✅ Evaluation complete!")
            st.json(metrics)

            # Radar Chart
            categories = list(metrics.keys())
            values = list(metrics.values())
            values += values[:1]

            fig = go.Figure(
                data=[go.Scatterpolar(
                    r=values,
                    theta=categories + [categories[0]],
                    fill='toself',
                    name='Quality Scores',
                    line_color='royalblue'
                )],
                layout=go.Layout(
                    polar=dict(radialaxis=dict(visible=True, range=[0, 5])),
                    showlegend=False,
                    title="Conversation Quality Radar"
                )
            )
            st.plotly_chart(fig, use_container_width=True)

            # Composite score
            overall = sum(metrics.values()) / len(metrics)
            st.metric("💯 Overall Quality Score", f"{overall:.2f} / 5")
