import numpy as np
from sklearn.metrics import average_precision_score
import random
from langchain_openai import ChatOpenAI
import os, httpx, json

# -------------------------------------------------------------------
# Step 1: Simulated retrieval results
# -------------------------------------------------------------------

retrieval_log = [
    {
        "query": "How can I reset my password?",
        "retrieved_chunks": [
            {"id": "chunk_1", "text": "Go to Account Settings and click 'Forgot Password'."},
            {"id": "chunk_2", "text": "We recommend using strong passwords to protect your account."},
            {"id": "chunk_3", "text": "To delete your account, contact support."},
        ],
    },
    {
        "query": "What are the refund rules for digital purchases?",
        "retrieved_chunks": [
            {"id": "chunk_4", "text": "Refunds for digital goods are available within 7 days if unused."},
            {"id": "chunk_5", "text": "Shipping is available to over 50 countries."},
            {"id": "chunk_6", "text": "Customers can request a refund through the portal."},
        ],
    },
]

# -------------------------------------------------------------------
# Step 2: Mock LLM evaluator (replace with real LLM call)
# -------------------------------------------------------------------

def mock_llm_relevance_judge(query, chunk_text):
    """Simulate an LLM evaluator that decides if chunk is relevant to query."""
    q = query.lower()
    c = chunk_text.lower()

    # simple heuristic for simulation
    if "password" in q and "password" in c:
        return 1
    elif "refund" in q and ("refund" in c or "return" in c):
        return 1
    else:
        return 0

# (Later replace with real LLM call like below)

client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    api_key="sk-Z6ZvcQAwUGMOReylW5me4Q",
    model="azure/genailab-maas-gpt-4o-mini",
    http_client=client
)
def llm_relevance_judge(query, chunk_text):
    prompt = f"""
    You are an evaluator determining whether a text chunk helps answer a query.
    Query: "{query}"
    Chunk: "{chunk_text}"
    Reply only with 'Relevant' or 'Not Relevant'.
    """
    response = llm.invoke(prompt)
    # print(response)
    result = response.content.strip().lower()
    return 1 if "relevant" in result and "not" not in result else 0

# -------------------------------------------------------------------
# Step 3: Generate relevance labels automatically
# -------------------------------------------------------------------

def generate_relevance_labels(retrieval_log, llm_relevance_judge):
    auto_labels = []
    for entry in retrieval_log:
        query = entry["query"]
        for chunk in entry["retrieved_chunks"]:
            rel = llm_relevance_judge(query, chunk["text"])
            auto_labels.append({
            "query": query,
            "chunk_id": chunk["id"],
            "relevance": rel
        })
            
    return auto_labels

auto_labels = generate_relevance_labels(retrieval_log, llm_relevance_judge)

# -------------------------------------------------------------------
# Step 4: Compute mAP
# -------------------------------------------------------------------

def compute_mAP_from_autoeval(retrieval_log, auto_labels):
    ap_scores = []
    for entry in retrieval_log:
        query = entry["query"]
        chunks = entry["retrieved_chunks"]

        # Binary relevance for each chunk (from evaluator)
        y_true = [next((x["relevance"] for x in auto_labels
                        if x["query"] == query and x["chunk_id"] == ch["id"]), 0)
                  for ch in chunks]

        # Simulated retriever scores (in real case use your retriever’s similarity scores)
        y_score = [random.random() for _ in chunks]

        if any(y_true):
            ap = average_precision_score(y_true, y_score)
            ap_scores.append(ap)

    return np.mean(ap_scores) if ap_scores else 0.0

mAP = compute_mAP_from_autoeval(retrieval_log, auto_labels)

# -------------------------------------------------------------------
# Step 5: Print results
# -------------------------------------------------------------------
def print_results(auto_labels, mAP):
    for entry in auto_labels:
        print(f"Query: {entry['query'][:40]:40s} | Chunk: {entry['chunk_id']:8s} | Relevant: {entry['relevance']}")

    print(f"\nAuto-evaluated metric mAP: {mAP:.3f}")

print_results(auto_labels, mAP)
