# pip install transformers torch
from transformers import pipeline

# Load once globally
toxic_classifier = pipeline("text-classification", model="unitary/toxic-bert", top_k=None)

def check_toxicity(text: str, threshold: float = 0.5):
    """
    Detects if text contains toxic or offensive language.
    Works with all pipeline output formats.
    """
    results = toxic_classifier(text)

    # Normalize: flatten nested lists if needed
    if isinstance(results, list) and len(results) > 0 and isinstance(results[0], list):
        results = results[0]  # unwrap inner list

    flagged = [r for r in results if r.get('score', 0) > threshold]

    return {
        "is_toxic": len(flagged) > 0,
        "toxic_labels": [(r['label'], round(r['score'], 3)) for r in flagged],
        "all_labels": [(r['label'], round(r['score'], 3)) for r in results],
    }

# Example test
if __name__ == "__main__":
    text = "I hate everyone who disagrees with me!"
    result = check_toxicity(text)
    print(result)
