from PyPDF2 import PdfReader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from transformers import AutoTokenizer, AutoModelForQuestionAnswering
from transformers import AutoTokenizer, pipeline
from langchain import HuggingFacePipeline
from langchain.chains import RetrievalQA
from langchain.chains.question_answering import load_qa_chain
from langchain_community.llms import CTransformers
from transformers import T5Tokenizer, T5ForConditionalGeneration
import os

file = open("TOSCA-Simple-Profile-YAML.pdf", "r")

os.environ["HUGGINGFACEHUB_API_TOKEN"] = "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"

#Extract the text
if file is not None:
    pdf_reader = PdfReader("TOSCA-Simple-Profile-YAML.pdf")
    text = ""
    for page in pdf_reader.pages:
        text += page.extract_text()
        #st.write(text)
        #print(text)

#Break it into chunks
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=150,
        length_function=len
    )
    chunks = text_splitter.split_text(text)
    #st.write(chunks)
    print(chunks[0])

    # Define the path to the pre-trained model you want to use
    modelPath = "all-MiniLM-L6-v2"

    # Create a dictionary with model configuration options, specifying to use the CPU for computations
    model_kwargs = {'device': 'cpu'}

    # Create a dictionary with encoding options, specifically setting 'normalize_embeddings' to False
    encode_kwargs = {'normalize_embeddings': False}

    # Initialize an instance of HuggingFaceEmbeddings with the specified parameters
    embeddings = HuggingFaceEmbeddings(
        model_name=modelPath,  # Provide the pre-trained model's path
        model_kwargs=model_kwargs,  # Pass the model configuration options
        encode_kwargs=encode_kwargs  # Pass the encoding options
    )

    #text = "This is a test document."
    #query_result = embeddings.embed_query(text)
    #print(query_result[:3])

    db = FAISS.from_texts(chunks, embeddings)

    question = "What is node template?"
    searchDocs = db.similarity_search(question)
    print(searchDocs[0].page_content)

    # Create a tokenizer object by loading the pretrained "Intel/dynamic_tinybert" tokenizer.
    #tokenizer = AutoTokenizer.from_pretrained("Intel/dynamic_tinybert")

    # Create a question-answering model object by loading the pretrained "Intel/dynamic_tinybert" model.
    #model = AutoModelForQuestionAnswering.from_pretrained("Intel/dynamic_tinybert")

    # Specify the model name you want to use
    #model_name = "llama-2-7b-model/llama-2-7b-chat.ggmlv3.q6_K.bin"

    #model_name = "MBZUAI/LaMini-Flan-T5-783M"

    # Load the tokenizer associated with the specified model
    #tokenizer = AutoTokenizer.from_pretrained(model_name, padding=True, truncation=True, max_length=512)

    #tokenizer = T5Tokenizer.from_pretrained("google/flan-t5-base")
    #model = T5ForConditionalGeneration.from_pretrained("google/flan-t5-base")

    # Define a question-answering pipeline using the model and tokenizer
    #question_answerer = pipeline(
    #    "text-generation",
    #    model=model_name,
    #    tokenizer=tokenizer,
    #    max_new_tokens=500,
    #    return_tensors='pt'
    #)

    # Create an instance of the HuggingFacePipeline, which wraps the question-answering pipeline
    # with additional model-specific arguments (temperature and max_length)
    #llm = HuggingFacePipeline(
    #    pipeline=question_answerer,
    #    model_kwargs={"temperature": 0.7, "max_length": 512},
    #)

    # Create a retriever object from the 'db' using the 'as_retriever' method.
    # This retriever is likely used for retrieving data or documents from the database.
    #retriever = db.as_retriever()

    #docs = retriever.get_relevant_documents("What is node_template ?")
    #print(docs[0].page_content)

    # Create a retriever object from the 'db' with a search configuration where it retrieves up to 4 relevant splits/documents.
    #retriever = db.as_retriever(search_kwargs={"k": 4})

    # Create a question-answering instance (qa) using the RetrievalQA class.
    # It's configured with a language model (llm), a chain type "refine," the retriever we created, and an option to not return source documents.
    #qa = RetrievalQA.from_chain_type(llm=llm, chain_type="refine", retriever=retriever, return_source_documents=False)

    llm = CTransformers(model='MBZUAI/LaMini-GPT-1.5B',
                        config={'max_new_tokens': 1024, 'temperature': 0.8, 'context_length': 2048})
    chain = load_qa_chain(llm, chain_type="stuff")



    question = "What is node_template?"
    response = chain.run(input_documents=searchDocs, question=question)

    #result = qa.run({"query": question})
    print(response)


