import streamlit as st
import logging

logging.basicConfig(format='%(asctime)s %(message)s', level=logging.DEBUG)

st.header("My chatbot")

input = st.text_input("Enter your prompt")

logging.info(input)

st.text(input)
