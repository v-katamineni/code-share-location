# pip install presidio-analyzer presidio-anonymizer
from presidio_analyzer import AnalyzerEngine
from presidio_anonymizer import AnonymizerEngine

# Initialize Presidio engines
analyzer = AnalyzerEngine()
anonymizer = AnonymizerEngine()

def anonymize_text(text: str):
    """
    Detects and replaces PII (names, phone numbers, emails, etc.)
    Args:
        text (str): Text to sanitize
    Returns:
        dict: {
            "has_pii": bool,
            "pii_entities": [list of detected entities],
            "anonymized_text": str
        }
    """
    results = analyzer.analyze(text=text, language='en') # Uses model en-core-web-lg-3.8.0
    has_pii = len(results) > 0
    pii_entities = [{
        "entity_type": r.entity_type,
        "text": text[r.start:r.end],
        "score": round(r.score, 2)
    } for r in results]

    anonymized_text = anonymizer.anonymize(text=text, analyzer_results=results).text
    return {
        "has_pii": has_pii,
        "pii_entities": pii_entities,
        "anonymized_text": anonymized_text
    }

# Example usage
if __name__ == "__main__":
    sample = "My name is John Doe. Email me at john.doe@example.com or call +1-202-555-0178."
    print(anonymize_text(sample))
