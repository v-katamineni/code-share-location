# pip install transformers torch
import transformers
from transformers import pipeline

moderator = pipeline("text-classification", model="unitary/toxic-bert")

text = "I hate you and everyone like you."

result = moderator(text)[0]
label, score = result['label'], result['score']

if label == "toxic" and score > 0.5:
    print("🚫 Toxic content detected! (score:", score, ")")
else:
    print("✅ Safe content.")
